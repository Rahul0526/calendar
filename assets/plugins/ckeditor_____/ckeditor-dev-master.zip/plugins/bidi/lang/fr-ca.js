/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'fr-ca', {
	ltr: 'Direction du texte de gauche à droite',
	rtl: 'Direction du texte de droite à gauche'
} );
