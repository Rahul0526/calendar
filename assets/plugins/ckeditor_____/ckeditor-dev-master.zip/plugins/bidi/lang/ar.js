/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'ar', {
	ltr: 'إتجاه النص من اليسار إلى اليمين',
	rtl: 'إتجاه النص من اليمين إلى اليسار'
} );
