/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'mk', {
	copy: 'Авторски права &copy; $1. Сите права се задржани.',
	dlgTitle: 'За CKEditor',
	help: 'Отворете $1 за помош.',
	moreInfo: 'За информации околу лиценцата, ве молиме посетете го нашиот веб-сајт: ',
	title: 'За CKEditor',
	userGuide: 'CKEditor упатство за корисници'
} );
