<?php
include_once 'header.php';
include_once 'left-menu.php';
?>
<div class="content-wrapper">
  
</div>
<?php
include_once 'footer.php';
?>